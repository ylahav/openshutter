import{L as m}from"../chunks/CVOENrm7.js";export{m as component};
