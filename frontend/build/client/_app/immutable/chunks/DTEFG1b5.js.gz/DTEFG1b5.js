import{ay as n,az as e}from"./CK0-DIe0.js";function a(t,i){t!=null&&typeof t.subscribe!="function"&&n(i)}function o(t){return t.toString=()=>(e(),""),t}export{o as p,a as v};
